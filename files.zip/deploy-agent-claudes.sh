#!/bin/bash
# deploy-agent-claudes.sh
# Deploys CLAUDE.md files to each agent directory in the Zazmic CRM project

BASE="/Users/zazmicinc/Projects/crm-project"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🚀 Deploying agent CLAUDE.md files to $BASE"
echo ""

deploy() {
  local src="$SCRIPT_DIR/$1/CLAUDE.md"
  local dest="$BASE/$1/CLAUDE.md"

  if [ ! -f "$src" ]; then
    echo "❌ Source not found: $src"
    return
  fi

  if [ -f "$dest" ]; then
    cp "$dest" "$dest.backup"
    echo "📦 Backed up existing: $1/CLAUDE.md → $1/CLAUDE.md.backup"
  fi

  cp "$src" "$dest"
  echo "✅ Deployed: $1/CLAUDE.md"
}

deploy "crm-frontend"
deploy "crm-backend"
deploy "database"
deploy "product"

echo ""
echo "✅ All agent CLAUDE.md files deployed."
echo ""
echo "Next steps:"
echo "  cd $BASE"
echo "  git add crm-frontend/CLAUDE.md crm-backend/CLAUDE.md database/CLAUDE.md product/CLAUDE.md"
echo "  git commit -m 'chore: add per-agent CLAUDE.md context files'"
echo "  git push"
